package org.insang.domain;

public enum Grade {
	A, B, C, D, F;
}
