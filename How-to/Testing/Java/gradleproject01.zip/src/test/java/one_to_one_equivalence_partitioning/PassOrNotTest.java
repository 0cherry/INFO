package one_to_one_equivalence_partitioning;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;

class PassOrNotTest {

	@DisplayName("��ȿ�� ����")
	@ParameterizedTest
	void should_give_pass_or_not() {
		
	}
	
	@DisplayName("��ȿ���� ���� ����")
	@ParameterizedTest
	void should_give_invalid_range_exception() {
		
	}

}
