package state_transition;

public enum ControllerState {
IDLE, OPERATING, COOLING, HEATING
}
