package one_to_one_equivalence_partitioning;

@SuppressWarnings("serial")
public class InvalidRangeException extends RuntimeException {
	public InvalidRangeException() {
		super();
	}
}
