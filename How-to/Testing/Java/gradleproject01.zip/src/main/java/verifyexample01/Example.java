package verifyexample01;

public class Example {
	private Doc doc;
	
	public void foo(int x) {
		if (x==1) {
			doc.say("yeongcheol");
//			doc.say("yeongcheol");
		}
		else {
			doc.say("kim");
			doc.say("kim");
		}
	}
}
