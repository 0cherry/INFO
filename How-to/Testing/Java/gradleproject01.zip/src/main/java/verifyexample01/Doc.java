package verifyexample01;

public class Doc {
	public void say(String name) {
		System.out.println(name);
	}
}
