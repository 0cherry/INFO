package _final_exam02;

@SuppressWarnings("serial")
public class InvalidRangeException extends RuntimeException {
	public InvalidRangeException() {
		super();
	}
}
