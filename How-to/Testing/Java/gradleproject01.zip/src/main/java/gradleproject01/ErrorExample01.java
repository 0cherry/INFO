package gradleproject01;

public class ErrorExample01 {
	public double devide(int x, int y) {
		return x/y;
	}
}
