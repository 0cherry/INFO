package gradleproject01;

public enum Grade {
	A, B, C, D, F
}
