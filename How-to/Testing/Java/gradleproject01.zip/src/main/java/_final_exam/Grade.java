package _final_exam;

public enum Grade {
	A, B, C, D, F
}
