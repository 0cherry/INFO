package _final_exam;

@SuppressWarnings("serial")
public class InvalidRangeException extends RuntimeException {
	public InvalidRangeException(String msg) {
		super(msg);
	}
}
