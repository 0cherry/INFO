package mockitoproject01;

public class BookException extends RuntimeException {
	public BookException(String msg) {
		super(msg);
	}
}
